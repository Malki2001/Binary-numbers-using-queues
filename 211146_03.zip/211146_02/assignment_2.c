#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

// make queue String array
int max;
char queue[100][500];
// make results String array
char result[100][500];

int front = -1;
int rear = -1;


int top = -1;
// For Copy the queue front value at that moment
char x[10];

int isEmpty()
{
    if (rear == -1 || front > rear)
        return 1;
    else
        return 0;
}

int isFull()
{
    if (rear == max - 1)
        return 1;
    else
        return 0;
}

void dequeue()
{
    if (isEmpty())
        printf("Queue is Underflow");

    else
    {
        top++;
        strcpy(result[top], queue[front]);
        front++;
    }
}

void enqueue()
{

    if (isFull())
        printf("Queue is Overflow");

    else
    {
        int count = 0;

        while (true)
        {
            if (front==-1 && rear==-1)
            {
                rear=0;
                front=0;
                strcpy(queue[rear], "1");

            }
            else if (rear < max)
            {
                // input "1" for queue(even indexes)
                if ((rear) != max-1  && (rear + 1) % 2 == 0 && count!=2)
                {
                    rear++;
                    strcpy(x,queue[front]);
                    strcpy(queue[rear], (strcat(x, "1")));
                    count++;
                }
                // input "0" for queue(odd indexes)
                else if ((rear) != max-1  && (rear + 1) % 2 != 0 && count!=2)
                {
                    rear++;
                    strcpy(x, queue[front]);
                    strcpy(queue[rear],(strcat(x, "0")));
                    count++;
                }
                else if ((rear) == max - 1)
                {

                    // assigning  queue's  values for results array
                    while (front <= max - 1)
                    {
                        dequeue();
                    }
                    break;
                }

                else if (count == 2)
                {
                    dequeue();
                    count = 0;
                }
            }
        }
    }

}
int main()
{
    printf("Enter the number of less than 500 :  ");
    scanf("%d",&max);

    enqueue();

    // print results
    for (int i = 0; i < max; i++)
        {
            printf("%d =\t %s\n", i+1 ,result[i]);
        }
    return 0;
}
